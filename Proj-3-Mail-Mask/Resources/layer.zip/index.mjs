// Updated for Node.js 22 (ES Module syntax for .mjs file)
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { simpleParser } from 'mailparser';
import { Readable } from 'stream';

// Initialize clients with default region
const REGION = process.env.AWS_REGION || 'us-east-1';
const sesClient = new SESClient({ region: REGION });
const s3Client = new S3Client({ region: REGION });
const dynamoClient = new DynamoDBClient({ region: REGION });
const dynamodb = DynamoDBDocumentClient.from(dynamoClient);

// Environment variable validation
const requiredEnvVars = [
    'MAPPING_TABLE',
    'FORWARDING_EMAIL',
    'DOMAIN_NAME',
    'S3_BUCKET'
];

export const handler = async (event) => {
    console.log('Processing incoming email event', JSON.stringify(event));
    
    // Validate environment variables
    for (const envVar of requiredEnvVars) {
        if (!process.env[envVar]) {
            const error = `Required environment variable ${envVar} is not set`;
            console.error(error);
            throw new Error(error);
        }
    }
    
    try {
        // Extract SES notification from the event
        const sesNotification = event.Records[0].ses;
        
        // Extract the message ID and recipient
        const messageId = sesNotification.mail.messageId;
        const maskedEmail = sesNotification.mail.destination[0];
        
        // Get the raw email from S3 
        // Note: This assumes SES is configured to save emails to S3
        const s3Key = `${messageId}`;
        
        let emailContent;
        try {
            const s3Response = await s3Client.send(new GetObjectCommand({
                Bucket: process.env.S3_BUCKET,
                Key: s3Key
            }));
            
            // Convert readable stream to string
            emailContent = await streamToString(s3Response.Body);
        } catch (s3Error) {
            console.error(`Error retrieving email from S3: ${s3Error.message}`);
            throw new Error(`Failed to retrieve email: ${s3Error.message}`);
        }
        
        // Parse the raw email
        const email = await simpleParser(emailContent);
        
        // Look up the real email address from DynamoDB
        const lookupResult = await dynamodb.send(new GetCommand({
            TableName: process.env.MAPPING_TABLE,
            Key: { masked_email: maskedEmail }
        }));
        
        if (!lookupResult.Item || !lookupResult.Item.real_email) {
            console.log(`No mapping found for ${maskedEmail}`);
            return {
                statusCode: 404,
                body: `No mapping found for ${maskedEmail}`
            };
        }
        
        const realEmail = lookupResult.Item.real_email;
        const settings = lookupResult.Item.settings || {};
        
        // Check if the masked email is active
        if (settings.active === false) {
            console.log(`Masked email ${maskedEmail} is inactive. Email not forwarded.`);
            return {
                statusCode: 200,
                body: `Masked email ${maskedEmail} is inactive. Email not forwarded.`
            };
        }
        
        // Extract sender information safely
        const senderEmail = email.from && email.from.value && 
                           email.from.value.length > 0 ? 
                           email.from.value[0].address : 
                           sesNotification.mail.source;
        
        const senderName = email.from && email.from.text ? 
                          email.from.text : 
                          senderEmail;
        
        // Prepare the email for forwarding
        const forwardingParams = {
            Source: process.env.FORWARDING_EMAIL,
            Destination: {
                ToAddresses: [realEmail]
            },
            Message: {
                Subject: {
                    Data: `[MASKED] ${email.subject || 'No Subject'}`
                },
                Body: {
                    Text: {
                        Data: `Original sender: ${senderName}\n\n${email.text || 'No text content'}`
                    }
                }
            },
            ReplyToAddresses: [
                `reply-${encodeURIComponent(senderEmail)}@${process.env.DOMAIN_NAME}`
            ]
        };
        
        // If HTML content exists and settings allow it, include it
        if (email.html && settings.forward_html !== false) {
            forwardingParams.Message.Body.Html = {
                Data: `<p><strong>Original sender:</strong> ${senderName}</p>${email.html}`
            };
        }
        
        // Handle attachments if settings allow
        if (email.attachments && email.attachments.length > 0 && settings.forward_attachments !== false) {
            // Note: Implementation for handling attachments is a complex topic
            // that would require additional AWS services like S3 for storage
            console.log(`Email has ${email.attachments.length} attachments to process`);
            // Implementation would go here...
        }
        
        // Forward the email using SES
        const result = await sesClient.send(new SendEmailCommand(forwardingParams));
        console.log(`Email forwarded successfully: ${result.MessageId}`);
        
        // Track usage statistics if needed
        await dynamodb.send(new UpdateCommand({
            TableName: process.env.MAPPING_TABLE,
            Key: { masked_email: maskedEmail },
            UpdateExpression: 'SET stats.emails_received = if_not_exists(stats.emails_received, :zero) + :one',
            ExpressionAttributeValues: {
                ':zero': 0,
                ':one': 1
            }
        }));
        
        return {
            statusCode: 200,
            body: `Email processed successfully. MessageId: ${result.MessageId}`
        };
    } catch (error) {
        console.error('Error processing email:', error);
        return {
            statusCode: 500,
            body: `Error processing email: ${error.message}`
        };
    }
};

// Helper function to convert readable stream to string
async function streamToString(stream) {
    if (stream instanceof Readable) {
        return new Promise((resolve, reject) => {
            const chunks = [];
            stream.on('data', (chunk) => chunks.push(chunk));
            stream.on('error', reject);
            stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        });
    } else {
        // Handle the case when stream is already a string or buffer
        return stream.toString('utf8');
    }
}
